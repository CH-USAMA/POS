<?php include('../partials/header.php'); ?>



<?php include('../partials/footer.php') ?>

<script>
    document.getElementById("breadcrumb").innerHTML = "Categories";
</script>

